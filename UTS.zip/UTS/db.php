<?php
    $dbhost = "sql205.epizy.com";
    $dbuser = "epiz_28586099";
    $dbpass = "Qrm51ka0A0nGk";
    $dbname = "epiz_28586099_gematkirana";

    $conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname) or die("Gagal Konek".$conn->error) ;
?>